package com.padcmyanmar.padc7.mmnews.mvp.views

interface BaseView {
}