package com.padcmyanmar.padc7.mmnews.views.holders;

import android.support.annotation.NonNull;
import android.view.View;

public class NewsSmallViewHolder extends BaseNewsViewHolder {

    public NewsSmallViewHolder(@NonNull View itemView) {
        super(itemView);
    }
}
