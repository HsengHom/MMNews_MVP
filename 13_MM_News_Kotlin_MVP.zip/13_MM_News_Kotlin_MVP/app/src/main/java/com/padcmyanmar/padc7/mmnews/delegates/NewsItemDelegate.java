package com.padcmyanmar.padc7.mmnews.delegates;

public interface NewsItemDelegate {

    void onTapNewsItem();
}
