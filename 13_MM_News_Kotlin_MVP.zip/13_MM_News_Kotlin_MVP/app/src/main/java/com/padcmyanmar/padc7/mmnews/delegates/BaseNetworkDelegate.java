package com.padcmyanmar.padc7.mmnews.delegates;

public interface BaseNetworkDelegate {

    void onFail(String msg);

}
