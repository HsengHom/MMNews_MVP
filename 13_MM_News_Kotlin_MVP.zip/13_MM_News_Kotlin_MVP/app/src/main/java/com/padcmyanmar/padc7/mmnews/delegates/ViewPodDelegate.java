package com.padcmyanmar.padc7.mmnews.delegates;

public interface ViewPodDelegate<T> {

    void setDelegate(T delegate);
}
