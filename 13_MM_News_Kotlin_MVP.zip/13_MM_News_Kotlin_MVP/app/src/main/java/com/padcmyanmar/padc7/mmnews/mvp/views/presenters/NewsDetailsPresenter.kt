package com.padcmyanmar.padc7.mmnews.mvp.views.presenters

interface NewsDetailsPresenter {


    fun goToDetailsNews()


}